import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = { title: "Ingenforge — Smarter help for assignments and studying", description: "AI-powered student study and assignment coach." };
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) { return <html lang="en"><body>{children}</body></html>; }
