# Ingenforge — AI Student Tool Demo

A complete demo built with Next.js App Router, TypeScript and Tailwind CSS.

## Included

- Landing page with pricing and CTAs
- Fake email/password signup + login (localStorage)
- Assignment Mode: topic, word count, requirements, PDF/DOCX/TXT draft upload
- Study Helper Mode: lecture PDF/DOCX/TXT upload + extra instructions
- OpenAI server-side integration using GPT-4o by default
- Exact system prompts requested for both modes
- 1 free AI use per local browser profile
- Server-enforced 10,000-character combined input + output limit for the free use, including extracted uploaded-file text
- Upgrade gate after the free use
- Fake payment flow that always succeeds
- Unlimited demo usage after fake payment
- Mobile responsive UI

## Run locally

1. Install Node.js 20+.
2. Copy `.env.example` to `.env.local`.
3. Put your OpenAI API key in `.env.local`:

```env
OPENAI_API_KEY=your_key_here
OPENAI_MODEL=gpt-4o
```

4. Install dependencies:

```bash
npm install
```

5. Start the development server:

```bash
npm run dev
```

Open http://localhost:3000.

## Demo flow

1. Click **Try Free**.
2. Create an account with any email and a password of 6+ characters.
3. Use Assignment Mode or Study Helper once.
4. After the first successful use, the dashboard shows the upgrade gate.
5. Click Upgrade → Pay £1.99 (Demo).
6. The account becomes unlimited for the demo.

### Reset the demo

Open browser DevTools → Application/Storage → Local Storage and remove:

- `ingenforge_user`
- `ingenforge_state`

## Important security note

The OpenAI key is read only by `/app/api/ai/route.ts` through `OPENAI_API_KEY`. Do not put the key in a `NEXT_PUBLIC_` variable and do not commit `.env.local`.

The authentication, subscription state and usage tracking are intentionally client-side for this demo. A production version should move those to a real database/auth system and verify entitlements on the server.

## Production next steps

- Replace fake auth with Auth.js/Clerk/Supabase/etc.
- Replace localStorage usage tracking with a database-backed credit ledger.
- Add Stripe Checkout + webhook verification.
- Add persistent document storage and virus/file-size validation.
- Add rate limiting and server-side subscription checks.
- Consider a newer OpenAI model after testing quality/cost against GPT-4o.
